//
//  MockWorker.swift
//  MyPortfolio
//
//  Created by Anti's Mac  on 09/01/25.
//

import Foundation

final class MockWorker: AsyncDataFetcher {

    var result: Result<PortfolioResponseModel, Error>?
    private(set) var totalPnL: Double = 0
    private(set) var currentVal: Double = 0
    private(set) var todaysPnL: Double = 0
    private(set) var totalInves: Double = 0

    func fetchData<T>(from url: URL) async throws -> T {
        guard let result else { throw URLError(.badURL) }
        switch result {
        case .success(let data):
            return data as! T
        case .failure(let error):
            throw error
        }
    }

    func generateMockDataModel() -> [HoldingDataModel] {
        guard case .success(let portfolioResponse) = result
        else { return [] }
        return portfolioResponse.data.userHolding.map {
            HoldingDataModel(
                stockName: $0.symbol,
                quantity: Double($0.quantity),
                ltp: $0.ltp,
                avgPrice: $0.avgPrice,
                close: $0.close
            )
        }
    }

    func updateValuation() {
        generateMockDataModel().forEach {
            totalPnL += $0.totalProfitAndLoss
            currentVal += $0.currentValue
            todaysPnL += $0.todaysProfitAndLoss
            totalInves += $0.totalInvestment
        }
    }
}
