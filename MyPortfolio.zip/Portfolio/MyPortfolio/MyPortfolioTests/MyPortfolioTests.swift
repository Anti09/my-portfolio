//
//  MyPortfolioTests.swift
//  MyPortfolioTests
//
//  Created by Pranjal  on 07/01/25.
//

import XCTest
@testable import MyPortfolio

final class MyPortfolioTests: XCTestCase {

    let model = HoldingDataModel(stockName: "MAHABANK", quantity: 990, ltp: 38.05, avgPrice: 35, close: 40)

    func testTotalProfit() {
        let profit = model.totalProfitAndLoss
        XCTAssertEqual(profit, 3019.5, "totalProfit should be 3019.5")
    }

    func testCurrentValue() {
        let currentValue = model.currentValue
        XCTAssertEqual(currentValue, 37669.5, "Current value should be 37669.5")
    }

    func testTotalInvestment() {
        let investment = model.totalInvestment
        XCTAssertEqual(investment, 34650, "total investment value should be 34650")
    }

}
