//
//  MyPortfolioViewModelTest.swift
//  MyPortfolio
//
//  Created by Anti's Mac  on 09/01/25.
//

import Combine
import XCTest
@testable import MyPortfolio

final class MyPortfolioViewModelTest: XCTestCase {

    var mockWorker: MockWorker?
    var viewModel: MyPortfolioViewModel?
    var cancellables =  Set<AnyCancellable>()
    var dataCodable = DataCodable()

    override func setUp() {
        super.setUp()
        mockWorker = MockWorker()
        viewModel = MyPortfolioViewModel(worker: mockWorker ?? MockWorker())
    }

    override func tearDown() {
        viewModel = nil
        mockWorker = nil
        super.tearDown()
    }

    func testLoadPortfolioDataSuccess() async {
        guard let jsonData = mockJSON.data(using: .utf8) else { return }
        do {
            let response = try dataCodable.decoder.decode(PortfolioResponseModel.self, from: jsonData)
            mockWorker?.result = .success(response)
            await viewModel?.loadPortfolioData(url: StringConstants.url)

            XCTAssertEqual(viewModel?.dataHoldingModel, mockWorker?.generateMockDataModel(), "The dataHoldingModel should be correctly populated")
        } catch {
            XCTFail("Test failed with error: \(error)")
        }
    }

    func testTotalValuation() {
        let tempValuation = [
            TotalValuationModel(key: StringConstants.currentValue, value: "\(mockWorker?.currentVal.amountWithLocale ?? "")"),
            TotalValuationModel(key: StringConstants.totalInvestment, value: "\(mockWorker?.totalInves.amountWithLocale ?? "")"),
            TotalValuationModel(key: StringConstants.todaysProfitNLoss, value: "\(mockWorker?.todaysPnL.amountWithLocale ?? "")", color: mockWorker?.todaysPnL.amountColor ?? .black)
        ]
        XCTAssertEqual(viewModel?.valuationModel, tempValuation, "The Valuation should be correctly populated")
    }

}
