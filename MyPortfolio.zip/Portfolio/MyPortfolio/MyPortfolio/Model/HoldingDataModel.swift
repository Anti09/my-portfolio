//
//  HoldingsDataModel.swift
//  MyPortfolio
//
//  Created by Pranjal  on 07/01/25.
//

struct HoldingDataModel: Codable, Equatable {
    let stockName: String
    let quantity: Double
    let ltp, avgPrice, close: Double

    var netQuantity: String {
        "\(Int(quantity))"
    }

    var currentValue: Double {
        ltp * quantity
    }

    var totalInvestment: Double {
        avgPrice * quantity
    }

    var totalProfitAndLoss: Double {
        currentValue - totalInvestment
    }

    var todaysProfitAndLoss: Double {
        (close - ltp) * quantity
    }
}
