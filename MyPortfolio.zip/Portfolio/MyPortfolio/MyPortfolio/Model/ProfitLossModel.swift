//
//  ProfitLossModel.swift
//  MyPortfolio
//
//  Created by Pranjal  on 08/01/25.
//
import UIKit

struct TotalValuationModel: Equatable {
    var key, value: String
    var color: UIColor = .black
}
