//
//  ResponseModel.swift
//  MyPortfolio
//
//  Created by Pranjal  on 07/01/25.
//

struct PortfolioResponseModel: Codable {
    let data: DataClass
}

struct DataClass: Codable {
    let userHolding: [UserHolding]
}

struct UserHolding: Codable {
    let symbol: String
    let quantity: Int
    let ltp, avgPrice, close: Double
}
