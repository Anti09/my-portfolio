//
//  Coordinator.swift
//  MyPortfolio
//
//  Created by Pranjal  on 07/01/25.
//

import UIKit


final class Coordinator {

    let navigationController: UINavigationController

    init(navigationController: UINavigationController) {
        self.navigationController = navigationController
    }

    func initial() {
        let viewModel = MyPortfolioViewModel(worker: NetworkManager())
        let portfolioVC = MyPortfolioViewController(viewModel: viewModel)
        navigationController.pushViewController(portfolioVC, animated: true)
    }
}
