//
//  HoldingValueView.swift
//  MyPortfolio
//
//  Created by Pranjal  on 08/01/25.
//

import UIKit
import Combine

final class MyHoldingView: UIStackView {

    private let titleLabel: UILabel = {
        let label = UILabel()
        label.font = .preferredFont(forTextStyle: .caption1)
        label.textColor = .secondaryLabel
        return label
    }()
    
    private let valueLabel: UILabel = {
        let label = UILabel()
        label.font = .preferredFont(forTextStyle: .body)
        return label
    }()

    private lazy var toggleButton: UIButton = {
        let button = UIButton()
        button.setImage(UIImage(resource: .toggle), for: .normal)
        button.addTarget(self, action: #selector(didTap), for: .touchUpInside)
        return button
    }()

    lazy var buttonTapped = PassthroughSubject<Bool, Never>()
    private var isToggle: Bool = false

    init(title: String) {
        super.init(frame: .zero)
        spacing = 4
        alignment = .center
        setupViews()
        titleLabel.text = title
    }
    
    required init(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    private func setupViews() {
        addArrangedSubview(titleLabel)
        addArrangedSubview(valueLabel)
    }

    func configView(_ text: String, _ color: UIColor = .secondaryLabel) {
        valueLabel.text = text
        valueLabel.textColor = color
    }

    func updateViewAppearance(titleLabelAlign: NSTextAlignment = .left, valueLabelAlign: NSTextAlignment = .right, _ titleTextColor: UIColor = .black, fontStyle: UIFont.TextStyle = .subheadline, isToggleNeeded: Bool = false) {
        titleLabel.textColor = titleTextColor
        titleLabel.font = UIFont.preferredFont(forTextStyle: fontStyle)
        if isToggleNeeded {
            insertArrangedSubview(toggleButton, at: 1)
            toggleButton.heightAnchor.constraint(equalToConstant: 20).isActive = true
            toggleButton.widthAnchor.constraint(equalToConstant: 20).isActive = true
            //Adding spacer
            insertArrangedSubview(UIView(), at: 2)

        }
    }

    func configGesture(isGesNeeded: Bool = false) {
        guard isGesNeeded else { return }
        let ges = UITapGestureRecognizer(target: self, action: #selector(didTap))
        addGestureRecognizer(ges)
    }

    @objc func didTap() {
        isToggle.toggle()
        UIView.animate(withDuration: 0.2, delay: 0, options: .curveEaseIn) {
            self.toggleButton.transform = self.toggleButton.transform.rotated(by: .pi)
        }
        buttonTapped.send(isToggle)
    }
}
