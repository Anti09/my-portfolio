//
//  ProfitLossView.swift
//  MyPortfolio
//
//  Created by Anti's Mac  on 08/01/25.
//

import UIKit

final class ProfitLossView: UIView {

    private lazy var verticalStack: UIStackView = {
        let stack = UIStackView()
        stack.axis = .vertical
        stack.distribution = .fillProportionally
        stack.translatesAutoresizingMaskIntoConstraints = false
        return stack
    }()

    private lazy var divider: UIView = {
        let view = UIView()
        view.backgroundColor = .black
        return view
    }()

    private lazy var currentValue = MyHoldingView(title: StringConstants.currentValue)
    private lazy var totalInvestment = MyHoldingView(title: StringConstants.totalInvestment)
    private lazy var todaysPnL = MyHoldingView(title: StringConstants.todaysProfitNLoss)
    var isViewHidden: Bool = true

    override init(frame: CGRect) {
        super.init(frame: frame)
        setupView()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    private func setupView() {
        addSubview(verticalStack)

        NSLayoutConstraint.activate([
            verticalStack.topAnchor.constraint(equalTo: topAnchor, constant: 8),
            verticalStack.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 16),
            verticalStack.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -16),
            verticalStack.bottomAnchor.constraint(equalTo: bottomAnchor, constant: -8),

            divider.heightAnchor.constraint(equalToConstant: 0.5)
        ])
    }

    func configView(model: [TotalValuationModel]) {
        verticalStack.removeAllSubViews()
        model.forEach {
            let view = MyHoldingView(title: $0.key)
            view.updateViewAppearance(titleLabelAlign: .left, valueLabelAlign: .right)
            view.configView($0.value, $0.color)
            verticalStack.addArrangedSubview(view)
        }
        verticalStack.insertArrangedSubview(divider, at: 3)
    }

}
