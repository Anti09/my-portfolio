//
//  PortfolioHoldingCell.swift
//  MyPortfolio
//
//  Created by Pranjal  on 08/01/25.
//

import UIKit

final class PortfolioHoldingCell: UITableViewCell {

    static let reuseIdentifier: String = "PortfolioHoldingCell"

    private let mainStack: UIStackView = {
        let stackView = UIStackView()
        stackView.axis = .vertical
        stackView.spacing = 16
        stackView.translatesAutoresizingMaskIntoConstraints = false
        return stackView
    }()

    private let holdingLabel: UILabel = {
        let label = UILabel()
        label.font = .preferredFont(forTextStyle: .headline)
        label.textColor = .label
        return label
    }()

    private let netQtyAndPLStack: UIStackView = {
        let stackView = UIStackView()
        stackView.spacing = 8
        return stackView
    }()

    private let ltpAndSymbolStack: UIStackView = {
        let stackView = UIStackView()
        stackView.spacing = 8
        return stackView
    }()

    private lazy var profitLossView = MyHoldingView(title: StringConstants.pNl)
    private lazy var netQtyView = MyHoldingView(title: StringConstants.netQuantity)
    private lazy var ltpView = MyHoldingView(title: StringConstants.ltd)

    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        selectionStyle = .none
        setupContainerView()
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    func config(holding: HoldingDataModel) {
        holdingLabel.text = holding.stockName
        netQtyView.configView(holding.netQuantity, .black)
        profitLossView.configView(holding.totalProfitAndLoss.amountWithLocale, holding.totalProfitAndLoss.amountColor)
        ltpView.configView(holding.ltp.amountWithLocale, .black)
    }
}

private extension PortfolioHoldingCell {

    func setupContainerView() {
        addSubview(mainStack)
        NSLayoutConstraint.activate([
            mainStack.topAnchor.constraint(equalTo: topAnchor, constant: 8),
            mainStack.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 16),
            mainStack.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -16),
            mainStack.bottomAnchor.constraint(equalTo: bottomAnchor, constant: -8)
        ])

        setupMainStackView()
        setupNetQtyAndPLStackView()
        setupSymbolAndLTPStackView()
    }

    func setupMainStackView() {
        mainStack.addArrangedSubview(ltpAndSymbolStack)
        mainStack.addArrangedSubview(netQtyAndPLStack)
    }

    func setupSymbolAndLTPStackView() {
        ltpAndSymbolStack.addArrangedSubview(holdingLabel)
        //Adding an empty view for spacer
        ltpAndSymbolStack.addArrangedSubview(UIView()) // Spacer
        ltpAndSymbolStack.addArrangedSubview(ltpView)
    }

    func setupNetQtyAndPLStackView() {
        netQtyAndPLStack.addArrangedSubview(netQtyView)
        //Adding an empty view for spacer
        netQtyAndPLStack.addArrangedSubview(UIView())
        netQtyAndPLStack.addArrangedSubview(profitLossView)
    }
}
