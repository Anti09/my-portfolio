//
//  MyPortfolioController.swift
//  MyPortfolio
//
//  Created by Pranjal  on 07/01/25.
//

import UIKit
import Combine

final class MyPortfolioViewController: UIViewController {

    private lazy var tableView: UITableView = {
        let view = UITableView()
        view.dataSource = self
        view.delegate = self
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()

    private lazy var myHoldingView: MyHoldingView = {
        let view = MyHoldingView(title: StringConstants.pNlKey)
        view.backgroundColor = .clear
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()

    private lazy var profitLossContainerView: UIView = {
        let view = UIView()
        view.backgroundColor = .systemGray5
        view.layer.cornerRadius = 10
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()

    private lazy var profitLossView: ProfitLossView = {
        let view = ProfitLossView()
        view.backgroundColor = .systemGray5
        view.layer.cornerRadius = 10
        view.layer.maskedCorners = [.layerMinXMinYCorner, .layerMaxXMinYCorner]
        view.translatesAutoresizingMaskIntoConstraints = false
        view.isHidden = true
        return view
    }()

    private lazy var activityIndicator: UIActivityIndicatorView = {
        let view = UIActivityIndicatorView(style: .medium)
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()

    private var viewModel: MyPortfolioViewModel
    private var cancellable = Set<AnyCancellable>()

    override func viewDidLoad() {
        super.viewDidLoad()
        title = StringConstants.myHoldings
        updateViewAppearance()
        setupView()
        setupTableViewConstraints()
        registerCell()
        setupSubscriber()
        loadData()
    }

    init(viewModel: MyPortfolioViewModel) {
        self.viewModel = viewModel
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    deinit {
        cancellable.removeAll()
    }
}

private extension MyPortfolioViewController {

    func updateViewAppearance() {
        view.backgroundColor = .systemGray5
        navigationController?.navigationBar.backgroundColor = .white
    }

    func setupView() {
        view.addSubview(tableView)
        view.addSubview(activityIndicator)
        view.addSubview(profitLossContainerView)
        profitLossContainerView.addSubview(myHoldingView)
        profitLossContainerView.addSubview(profitLossView)
    }

    func registerCell() {
        tableView.register(PortfolioHoldingCell.self, forCellReuseIdentifier: PortfolioHoldingCell.reuseIdentifier)
    }

    func setupTableViewConstraints() {
        NSLayoutConstraint.activate([
            tableView.topAnchor.constraint(equalTo: view.topAnchor),
            tableView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            tableView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            activityIndicator.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            activityIndicator.centerYAnchor.constraint(equalTo: view.centerYAnchor),

            profitLossContainerView.topAnchor.constraint(equalTo: tableView.bottomAnchor),
            profitLossContainerView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            profitLossContainerView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            profitLossContainerView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor),
            profitLossContainerView.heightAnchor.constraint(greaterThanOrEqualToConstant: 40),

            myHoldingView.topAnchor.constraint(equalTo: profitLossContainerView.topAnchor),
            myHoldingView.leadingAnchor.constraint(equalTo: profitLossContainerView.leadingAnchor, constant: 16),
            myHoldingView.trailingAnchor.constraint(equalTo: profitLossContainerView.trailingAnchor, constant: -16),
            myHoldingView.bottomAnchor.constraint(equalTo: profitLossContainerView.bottomAnchor),

            profitLossView.topAnchor.constraint(equalTo: profitLossContainerView.topAnchor),
            profitLossView.leadingAnchor.constraint(equalTo: profitLossContainerView.leadingAnchor),
            profitLossView.trailingAnchor.constraint(equalTo: profitLossContainerView.trailingAnchor),
            profitLossView.heightAnchor.constraint(equalToConstant: 130)
        ])
    }

    func loadData() {
        activityIndicator.startAnimating()
        guard viewModel.checkExistingHoldings
        else {
            Task {
                await viewModel.loadPortfolioData(url: StringConstants.url)
            }
            return
        }
    }

    func setupSubscriber() {
        viewModel.$dataHoldingModel
            .receive(on: DispatchQueue.main)
            .sink { [weak self] holdingModel in
                guard let self, !holdingModel.isEmpty
                else { return }
                activityIndicator.stopAnimating()
                tableView.reloadData()
                configProfitLossView(pNl: viewModel.totalPnL.amountWithLocale)
            }
            .store(in: &cancellable)

        myHoldingView.buttonTapped
            .receive(on: DispatchQueue.main)
            .sink { [weak self] toggle in
                guard let self else {
                    self?.profitLossView.isHidden = true
                    return
                }
                profitLossView.configView(model: viewModel.valuationModel)
                profitLossView.isHidden = !toggle
                animateView()
            }
            .store(in: &cancellable)

        viewModel.errorSubject
            .receive(on: DispatchQueue.main)
            .sink { [weak self] errorMessage in
                guard let self else { return }
                activityIndicator.stopAnimating()
                showAlert(with: errorMessage)
            }
            .store(in: &cancellable)
    }

    func configProfitLossView(pNl: String) {
        myHoldingView.configView(pNl, viewModel.totalPnL.amountColor)
        myHoldingView.updateViewAppearance(.black, isToggleNeeded: true)
        myHoldingView.configGesture(isGesNeeded: true)
    }

    func animateView() {
        self.profitLossView.frame.origin.y = -120
    }
}

extension MyPortfolioViewController: UITableViewDelegate, UITableViewDataSource {

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: PortfolioHoldingCell.reuseIdentifier, for: indexPath) as? PortfolioHoldingCell
        else { return UITableViewCell() }
        cell.config(holding: viewModel.getHolding(at: indexPath.row))
        return cell
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        viewModel.dataHoldingModel.count
    }
}
