//
//  MyPortfolioViewModel.swift
//  MyPortfolio
//
//  Created by Pranjal  on 07/01/25.
//

import Combine
import Foundation

final class MyPortfolioViewModel {

    var worker: AsyncDataFetcher
    private var cancellable = Set<AnyCancellable>()
    @Published var dataHoldingModel: [HoldingDataModel] = []
    private var dataCodable = DataCodable()
    private var persister = DataPersister()
    private(set) var totalPnL: Double = 0
    private(set) var currentVal: Double = 0
    private(set) var todaysPnL: Double = 0
    private(set) var totalInves: Double = 0
    var errorSubject = PassthroughSubject<String, Never>()

    init(worker: AsyncDataFetcher) {
        self.worker = worker
    }

    func loadPortfolioData(url: String) async {
        guard let url = URL(string: url)
        else {
            errorSubject.send(StringConstants.someThingWentWrong)
            return
        }
        do {
            let portfolio: PortfolioResponseModel = try await worker.fetchData(from: url)
            dataHoldingModel = generateDataModel(portfolio)
            updateValuation()
            saveHoldings(dataHoldingModel)
        } catch {
            errorSubject.send(StringConstants.couldNotFetchData)
        }
    }

    func getHolding(at index: Int) -> HoldingDataModel {
        dataHoldingModel[index]
    }

    var checkExistingHoldings: Bool {
        let holdings = fetchHoldings(model: [HoldingDataModel].self)
        guard !holdings.isEmpty
        else { return false }
        dataHoldingModel = holdings
        updateValuation()
        return true
    }

    func updateValuation() {
        dataHoldingModel.forEach {
            totalPnL += $0.totalProfitAndLoss
            currentVal += $0.currentValue
            todaysPnL += $0.todaysProfitAndLoss
            totalInves += $0.totalInvestment
        }
    }

    var valuationModel: [TotalValuationModel] {
        [
            TotalValuationModel(key: StringConstants.currentValue, value: "\(currentVal.amountWithLocale)"),
            TotalValuationModel(key: StringConstants.totalInvestment, value: "\(totalInves.amountWithLocale)"),
            TotalValuationModel(key: StringConstants.todaysProfitNLoss, value: "\(todaysPnL.amountWithLocale)", color: todaysPnL.amountColor)
        ]
    }
}

private extension MyPortfolioViewModel {
    func generateDataModel(_ model: PortfolioResponseModel) -> [HoldingDataModel] {
        model.data.userHolding.map {
            HoldingDataModel(
                stockName: $0.symbol,
                quantity: Double($0.quantity),
                ltp: $0.ltp,
                avgPrice: $0.avgPrice,
                close: $0.close
            )
        }
    }

    func saveHoldings(_ model: [HoldingDataModel], for key: String = StringConstants.myHoldingsKey) {
        do {
            let data = try dataCodable.encodeData(model)
            persister.saveData(set: data, for: key)
        } catch {
            errorSubject.send(StringConstants.someThingWentWrong)
        }
    }

    func fetchHoldings(for key: String = StringConstants.myHoldingsKey, model: [HoldingDataModel].Type) -> [HoldingDataModel] {
        do {
            guard let data = persister.fetchPersistedData(for: key) as? Data,
                  let model = try dataCodable.decodeData(from: data, type: model.self) as? [HoldingDataModel]
            else { return [] }
            return model
        } catch {
            errorSubject.send(StringConstants.couldNotFetchData)
            return []
        }
    }
}
