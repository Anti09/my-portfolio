//
//  Utility+UserDefaults.swift
//  MyPortfolio
//
//  Created by Anti's Mac  on 08/01/25.
//

import Foundation

final class DataPersister {

    private var userDefault = UserDefaults.standard

    init(userDefaults: UserDefaults = UserDefaults.standard) {
        self.userDefault = userDefaults
    }

    func saveData(set value: Any, for key: String) {
        userDefault.set(value, forKey: key)
    }

    func fetchPersistedData(for key: String) -> Any?  {
        userDefault.value(forKey: key)
    }
}
