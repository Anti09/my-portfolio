//
//  UI+Extension.swift
//  MyPortfolio
//
//  Created by Anti's Mac  on 09/01/25.
//
import UIKit

extension UIStackView {
    func removeAllSubViews() {
        subviews.forEach { $0.removeFromSuperview() }
    }
}

extension UIViewController {
    func showAlert(with message: String) {
        let alert = UIAlertController(title: StringConstants.alert, message: message, preferredStyle: .alert)
        let action = UIAlertAction(title: StringConstants.ok, style: .cancel)
        alert.addAction(action)
        present(alert, animated: true)
    }
}
