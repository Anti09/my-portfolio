//
//  StringConstants.swift
//  MyPortfolio
//
//  Created by Pranjal on 09/01/25.
//

final class StringConstants {
    static let url = "https://35dee773a9ec441e9f38d5fc249406ce.api.mockbin.io"
    static let currencyCode = "INR"
    static let myHoldings = "My Portfolio"
    static let pNl = "P&L:"
    static let ltd = "LTD:"
    static let netQuantity = "NET QTY:"

    static let myHoldingsKey = "MyHolding"
    static let currentValue = "Current Value* "
    static let totalInvestment = "Total Investment* "
    static let todaysProfitNLoss = "Today's Profit & Loss* "
    static let pNlKey = "Profit & Loss* "

    static let someThingWentWrong = "Something went wrong. Please try again later."
    static let couldNotFetchData = "Sorry Couldn't able to fetch data."
    static let noDataFound = "No Data Found."

    static let alert = "Alert"
    static let ok = "OK"
}
