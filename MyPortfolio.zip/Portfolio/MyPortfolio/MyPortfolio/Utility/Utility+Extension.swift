//
//  Utility+ExtensionDouble.swift
//  MyPortfolio
//
//  Created by Pranjal on 09/01/25.
//

import UIKit

extension Double {
    var amountWithLocale: String {
        self.formatted(.currency(code: StringConstants.currencyCode)).filter { !$0.isWhitespace }
    }

    var amountColor: UIColor {
        self > 0 ? UIColor.systemGreen : UIColor.red
    }
}
