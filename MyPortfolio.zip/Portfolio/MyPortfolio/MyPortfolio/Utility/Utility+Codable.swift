//
//  Utility+Codable.swift
//  MyPortfolio
//
//  Created by Pranjal  on 08/01/25.
//
import Foundation

final class DataCodable {
    let encoder: JSONEncoder
    let decoder: JSONDecoder

    init(encoder: JSONEncoder = JSONEncoder(), decoder: JSONDecoder = JSONDecoder()) {
        self.decoder = decoder
        self.encoder = encoder
    }

    func encodeData(_ model: Codable) throws -> Data {
        try encoder.encode(model)
    }

    func decodeData(from data: Data, type model: Decodable.Type) throws -> any Decodable {
        do {
            return try decoder.decode(model.self, from: data)
        } catch {
            throw error
        }
    }
}
