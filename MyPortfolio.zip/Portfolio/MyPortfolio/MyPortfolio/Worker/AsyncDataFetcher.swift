//
//  ApiWorkerProtocol.swift
//  MyPortfolio
//
//  Created by Pranjal  on 07/01/25.
//

import Combine
import Foundation

protocol AsyncDataFetcher {
    func fetchData<T: Codable>(from url: URL) async throws -> T
}

final class NetworkManager: AsyncDataFetcher {
    
    var session: URLSession
    init(session: URLSession = URLSession.shared) {
        self.session = session
    }

    func fetchData<T: Codable>(from url: URL) async throws -> T {
        let (data, response) = try await session.data(from: url)

        guard let httpResponse = response as? HTTPURLResponse, (200...299).contains(httpResponse.statusCode) else {
            throw URLError(.badServerResponse)
        }

        let decoder = JSONDecoder()
        do {
            let decodedData = try decoder.decode(T.self, from: data)
            return decodedData
        } catch {
            throw error
        }
    }
}
